<?php $__env->startSection('content'); ?>
	<div class="container">
		<?php if(session('mensaje')): ?>
	    <div class="alert alert-success fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('mensaje')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<?php if(session('usuarioBorrado')): ?>
	    <div class="alert alert-danger fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('usuarioBorrado')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<?php if(session('edicion')): ?>
	    <div class="alert alert-warning fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('edicion')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<div class="card">
			<div class="card-header">Usuarios</div>
			<div class="table-responsive">
				<table class="table">
				  	<thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Nombre</th>
					      <th scope="col">Apellido</th>
					      <th scope="col">Email</th>
					      <th scope="col">Tipo</th>
					      <th scope="col">Editar/Eliminar</th>
					    </tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th scope="row"><?php echo e($usuario->id); ?></th>
					      <td><?php echo e($usuario->name); ?></td>
					      <td><?php echo e($usuario->lastname); ?></td>
					      <td><?php echo e($usuario->email); ?></td>
					      <td>
					      	<?php if($usuario->type == 'admin'): ?>
					      		<span class="badge badge-primary">Admin</span>
					      	<?php else: ?>
					      		<span class="badge badge-danger">Cliente</span>
					      	<?php endif; ?>
					      </td>
					      <td>
					      	<span>
					      	<a href="<?php echo e(route('users.edit', $usuario->id)); ?>">
					      		<button type="button" class="btn btn-warning" title="Editar"><i class="fas fa-pencil-alt"></i></button>
					      	</a>
					      	</span>
					      	<span class="float-right">
					      	<form class="d-inline" method="post" action="<?php echo e(route('users.destroy', $usuario->id)); ?>">
					      		<?php echo method_field('DELETE'); ?>
					      		<?php echo csrf_field(); ?>
					      		<button type="submit" class="btn btn-danger" title="Eliminar" onclick="return confirm('Estas seguro que deseas eliminarlo?')"><i class="fas fa-trash-alt"></i></button>
					      	</form>
					      	</span>

					      </td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>

		<?php echo $usuarios->render(); ?>


		<br>
		<a href="<?php echo e(route('admin.home')); ?>"><button type="button" class="btn btn-secondary btn-sm">Volver</button></a>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/admin/usuarios.blade.php ENDPATH**/ ?>