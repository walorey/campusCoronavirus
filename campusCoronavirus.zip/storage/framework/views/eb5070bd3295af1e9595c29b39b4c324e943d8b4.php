<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row justify-content-center">
        	<div class="col-md-8">
				<div class="card">
		            <div class="card-header">Panel administrativo</div>
					<div class="card-body">
						<div class="btn-group">
						  <button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						    Usuarios
						  </button>
						  <div class="dropdown-menu">
						    <a class="dropdown-item" href="<?php echo e(route('users.create')); ?>">Crear usuario</a>
						    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">Ver usuarios</a>
						  </div>
						</div>
						<div class="btn-group">
						  <button class="btn btn-danger btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						    Archivos
						  </button>
						  <div class="dropdown-menu">
						    <a class="dropdown-item" href="<?php echo e(route('subir.archivo')); ?>">Subir archivo</a>
						    <a class="dropdown-item" href="<?php echo e(route('files.index')); ?>">Ver archivos</a>
						  </div>
						</div>
						<div class="btn-group">
							<a href="<?php echo e(route('foro.index')); ?>">
								<button class="btn btn-success btn-lg " type="button" aria-haspopup="true" aria-expanded="false">
						         Foro
						  		</button>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/admin/home.blade.php ENDPATH**/ ?>