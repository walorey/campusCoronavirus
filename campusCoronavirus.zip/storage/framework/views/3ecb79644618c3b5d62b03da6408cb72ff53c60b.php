<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Bienvenido!</div>

                <div class="card-body">
                    <div class="btn-group">
                        <a href="<?php echo e(route('foro.index')); ?>">
                            <button class="btn btn-success btn-lg" type="button">
                                Foro
                            </button>
                        </a>
                    </div>
                                        <div class="btn-group">
                        <a href="<?php echo e(route('materialDidactico')); ?>">
                            <button class="btn btn-dark btn-lg" type="button">
                                Material didáctico
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/home.blade.php ENDPATH**/ ?>