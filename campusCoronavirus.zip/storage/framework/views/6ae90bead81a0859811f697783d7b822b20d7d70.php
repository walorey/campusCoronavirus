<?php $__env->startSection('content'); ?>
	<div class="container">
		<nav class="navbar navbar-light bg-dark rounded">
		  <a class="navbar-brand text-light" href="#">
		  	<span class="bg-light rounded">
		    	<img src="<?php echo e(asset('img/logo.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="">
		    </span>
		    Material didáctico
		  </a>
		</nav>
		<br>
		<?php for($i=1; $i<6; $i++): ?>
		<div class="accordion" id="accordion<?php echo e($i); ?>">

		  <div class="card">
		    <div class="card-header" id="heading<?php echo e($i); ?>">
		      <h2 class="mb-0">
		        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($i); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($i); ?>">
		          Módulo <?php echo e($i); ?>

		        </button>
		      </h2>
		    </div>

		    <div id="collapse<?php echo e($i); ?>" class="collapse show" aria-labelledby="heading<?php echo e($i); ?>" data-parent="#accordion<?php echo e($i); ?>">
		      <div class="card-body">
		      	<div class="card-group">
		      		<?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      			<?php if($archivo->modulo == $i): ?>
						  <div class="card">
						    <div class="card-body">
								<h5 class="card-title"><?php echo e($archivo->name); ?></h5>
								<p class="card-text"><?php echo e($archivo->descripcion); ?></p>
								<a href="<?php echo e(asset($archivo->ruta)); ?>" class="btn btn-primary" target="_blank">Ver</a>
						    </div>
						  </div>
		      			<?php endif; ?>
		      		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
		      </div>
		    </div>
		  </div>
		</div>
		<?php endfor; ?>

		<div class="accordion" id="accordionExamenes">
		  <div class="card">
		    <div class="card-header" id="headingExamenes">
		      <h2 class="mb-0">
		        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseExamenes" aria-expanded="true" aria-controls="collapseExamenes">
		          Exámenes
		        </button>
		      </h2>
		    </div>

		    <div id="collapseExamenes" class="collapse show" aria-labelledby="headingExamenes" data-parent="#accordionExamenes">
		      <div class="card-body">
				<?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($archivo->modulo == 6): ?>
					<div class="card-group">
						<div class="card">
							<div class="card-body">
								<h5 class="card-title"><?php echo e($archivo->name); ?></h5>
								<p class="card-text"><?php echo e($archivo->descripcion); ?></p>
								<a href="<?php echo e(asset($archivo->ruta)); ?>" class="btn btn-primary" target="_blank">Ver</a>
							</div>
						</div>
					</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </div>
		    </div>
		  </div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/material.blade.php ENDPATH**/ ?>