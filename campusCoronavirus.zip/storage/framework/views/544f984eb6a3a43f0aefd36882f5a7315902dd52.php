<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="card bg-light mb-3">
		  <div class="card-header">
		  	<?php echo e($pregunta->user->name.' '.$pregunta->user->lastname); ?>


		  	<?php if(Auth::user()->type == 'admin' || Auth::user()->id == $pregunta->user->id): ?>
		  		<span class="float-right">
			  	  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <?php if(Auth::user()->id == $pregunta->user->id): ?>
                      <a class="dropdown-item text-center" href="<?php echo e(route('foro.edit', $pregunta->id)); ?>">Editar</a>
                      <div class="dropdown-divider"></div>
                      <?php endif; ?>
                      <a class="dropdown-item text-center" type="button" data-toggle="modal" data-target="#modalBorrar">Eliminar</a>
                    </div>
                  </div>
			  	</span>
		  	<?php endif; ?>
		  	<span class="float-right">
		  		<?php echo e($pregunta->created_at); ?>

		  	</span>
		  </div>
		  <div class="card-body">
		    <h5 class="card-title"><?php echo e($pregunta->titulo); ?></h5>
		    <p class="card-text"><?php echo e($pregunta->cuerpo); ?></p>
		  </div>
		</div>
		<br>
		<h3>Comentarios</h3>
		<?php $__currentLoopData = $pregunta->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="card border-light mb-3">
		  <div class="card-header"><?php echo e($comentario->user->name.' '.$comentario->user->lastname); ?></div>
		  <div class="card-body">
		    <p class="card-text"><?php echo e($comentario->cuerpo); ?></p>
		  </div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php if(Auth::user()->type == 'admin'): ?>
			<?php if(session('mensaje')): ?>
		    <div class="alert alert-success fade show">
		    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				</button>
		        <ul>
					<?php echo e(session('mensaje')); ?>

		        </ul>
		    </div>
		    <?php endif; ?>
		<div class="card bg-light mb-3">
		  <div class="card-header">Comentar</div>
		  <div class="card-body">
		  	<form action="<?php echo e(route('comentar.store', $pregunta->id)); ?>" method="post" id="formComentario">
		  		<?php echo csrf_field(); ?>
			  <div class="form-group">
			    <textarea class="form-control" name="cuerpo" rows="3" required=""></textarea>
			  </div>
			</form>
		  </div>
		  <div class="card-footer">
		  	<span class="float-right">
		  	<button type="submit" class="btn btn-outline-primary btn-sm" form="formComentario">Enviar</button>
		  	</span>
		  </div>
		</div>
		<?php endif; ?>
	</div>

	<!-- Modal -->
	<div class="modal fade" id="modalBorrar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">¿Borrar pregunta?</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-footer">
	      	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
	      	<form class="d-inline" method="post" action="<?php echo e(route('foro.destroy', $pregunta->id)); ?>">
				<?php echo method_field('DELETE'); ?>
				<?php echo csrf_field(); ?>
				<button type="submit" class="btn btn-danger">Borrar</button>
			</form>


	      </div>
	    </div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/foro/pregunta.blade.php ENDPATH**/ ?>