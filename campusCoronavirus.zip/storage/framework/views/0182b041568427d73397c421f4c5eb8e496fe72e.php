<?php $__env->startSection('content'); ?>

	<div class="container">

		<?php if($errors->any()): ?>
	    <div class="alert alert-danger fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
	            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <li><?php echo e($error); ?></li>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </ul>
	    </div>
		<?php endif; ?>

		<div class="card">
		  <div class="card-header">
		    Subir un archivo
		  </div>
		  <div class="card-body">
			<form action="<?php echo e(route('files.update', $archivo)); ?>" class="dropzone" enctype="multipart/form-data" method="post" id="formArchivo">
			  <?php echo method_field('PUT'); ?>
			  <?php echo csrf_field(); ?>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Nombre del archivo</label>
			    <input type="text" required="" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Introduccion, bibliografía, calificaciones, etc" value="<?php echo e($archivo->name); ?>">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlSelect1">Módulo</label>
			    <select class="form-control" name="modulo" id="exampleFormControlSelect1">
			      <option value="<?php echo e($archivo->modulo); ?>" selected><?php echo e($archivo->modulo); ?></option>
			      <option disabled>Seleccionar</option>
			      <option value="1">1</option>
			      <option value="2">2</option>
			      <option value="3">3</option>
			      <option value="4">4</option>
			      <option value="5">5</option>
			    </select>
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlFile1">Carga un archivo</label>
			    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="archivo">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlTextarea1">Descripción</label>
			    <textarea class="form-control" required="" id="exampleFormControlTextarea1" name="descripcion" rows="3"><?php echo e($archivo->descripcion); ?></textarea>
			  </div>
			  <button type="submit" form="formArchivo" class="btn btn-success">Guardar</button>
			</form>
		  </div>
		</div>

		<br>

		<a href="<?php echo e(route('files.index')); ?>"><button type="button" class="btn btn-secondary btn-sm">Volver</button></a>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/admin/editarArchivo.blade.php ENDPATH**/ ?>