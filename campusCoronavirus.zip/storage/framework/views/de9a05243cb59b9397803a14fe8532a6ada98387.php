<?php $__env->startSection('styles'); ?>
	   <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<?php if(session('mensaje')): ?>
	    <div class="alert alert-success fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('mensaje')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<?php if(session('preguntaBorrada')): ?>
	    <div class="alert alert-danger fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('preguntaBorrada')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<?php if(session('edicion')): ?>
	    <div class="alert alert-warning fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('edicion')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<!-- Image and text -->
		<nav class="navbar navbar-light bg-success rounded">
		  <a class="navbar-brand text-light" href="<?php echo e(route('foro.index')); ?>">
		    <img src="<?php echo e(asset('img/logo.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="">
		    Foro
		  </a>
		</nav>
		<br>

		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
				<div class="card bg-light mb-3" style="max-width: 21rem;">
				  <div class="card-header text-center">Menú</div>
				  <div class="card-body">
					<button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#preguntar">Hacer una pregunta</button>
					<br>
					<a href="<?php echo e(route('misPreguntas')); ?>" class="link-limpio-blanco">
						<button type="button" class="btn btn-info btn-block">Mis preguntas</button>
					</a>
				  </div>
				</div>
			</div>
			<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
				<?php if($preguntas->count()>0): ?>
					<?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card text-white bg-info mb-3">
						  <div class="card-header">
						  	<span><?php echo e($pregunta->user->name.' '.$pregunta->user->lastname); ?></span>
						  	<?php if(Auth::user()->type == 'admin' || Auth::user()->id == $pregunta->user->id): ?>
						  		<span class="float-right">
							  	  <div class="dropdown no-arrow">
				                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
				                    </a>
				                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
				                      <?php if(Auth::user()->id == $pregunta->user->id): ?>
				                      <a class="dropdown-item text-center" href="<?php echo e(route('foro.edit', $pregunta->id)); ?>">Editar</a>
				                      <div class="dropdown-divider"></div>
				                      <?php endif; ?>
				                      <a class="dropdown-item text-center" type="button" data-toggle="modal" data-target="#modalBorrar<?php echo e($pregunta->id); ?>">Eliminar</a>
				                    </div>
				                  </div>
							  	</span>
						  	<?php endif; ?>
						  	<span class="float-right">
						  		<?php echo e($pregunta->created_at); ?>

						  	</span>
						  </div>
						  <div class="card-body">
						    <h5 class="card-title"><?php echo e($pregunta->titulo); ?></h5>
						 </div>
						 <div class="card-footer">
						 	<a href="<?php echo e(route('foro.show', $pregunta->id)); ?>" class="link-limpio-blanco">Ver</a>
						 </div>
						</div>



												<!-- Modal borrar -->
						<div class="modal fade" id="modalBorrar<?php echo e($pregunta->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLabel">¿Borrar pregunta?</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-footer">
						      	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
						      	<form class="d-inline" method="post" action="<?php echo e(route('foro.destroy', $pregunta->id)); ?>">
									<?php echo method_field('DELETE'); ?>
									<?php echo csrf_field(); ?>
									<button type="submit" class="btn btn-danger">Borrar</button>
								</form>


						      </div>
						    </div>
						  </div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<br>
				<?php else: ?>
					<h3>Aún no hay preguntas, si tienes dudas puedes hacer una!</h3>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<!-- Modal hacer una pregunta-->
	<div class="modal fade" id="preguntar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">¿Cuál es tu duda?</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <form action="<?php echo e(route('foro.store')); ?>" method="post" id="formPregunta">
	        	<?php echo csrf_field(); ?>
	        	<div class="form-group">
			   		<label>Pregunta</label>
			    	<input type="text" class="form-control" required name="titulo">
			  	</div>
			  	<div class="form-group">
			  		<label for="exampleFormControlTextarea1">Detalles</label>
    				<textarea class="form-control" required name="cuerpo" rows="3"></textarea>
			  	</div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn-primary" form="formPregunta">Preguntar</button>
	      </div>
	    </div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/foro/home.blade.php ENDPATH**/ ?>