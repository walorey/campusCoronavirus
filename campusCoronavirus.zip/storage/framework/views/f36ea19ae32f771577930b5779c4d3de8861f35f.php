<?php $__env->startSection('content'); ?>

	<div class="container">

		<?php if($errors->any()): ?>
	    <div class="alert alert-danger fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
	            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <li><?php echo e($error); ?></li>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </ul>
	    </div>
		<?php endif; ?>

		<div class="card">
		  <div class="card-header">
		    Editar usuario
		  </div>
		  <div class="card-body">
			<form action="<?php echo e(route('users.update', $usuario->id)); ?>"  method="post">
			  <?php echo method_field('PUT'); ?>
			  <?php echo csrf_field(); ?>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Nombre</label>
			    <input type="text"  name="name" class="form-control" value="<?php echo e($usuario->name); ?>" placeholder="Primer nombre">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Apellido</label>
			    <input type="text"  name="lastname" class="form-control" value="<?php echo e($usuario->lastname); ?>" placeholder="Apellido">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Email</label>
			    <input type="email"  name="email" class="form-control" value="<?php echo e($usuario->email); ?>" placeholder="nombre@ejemplo.com">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlSelect1">Tipo</label>
			    <select class="form-control" name="type" id="exampleFormControlSelect1">
                  <?php if($usuario->type == 'admin'): ?>
                  <option value="admin" selected>Administrador</option>
                  <?php else: ?>
                  <option value="member" selected>Cliente</option>
                  <?php endif; ?>
			      <option disabled>Seleccionar</option>
			      <option value="admin">Administrador</option>
			      <option value="member">Cliente</option>
			    </select>
			  </div>
			  <button type="submit" class="btn btn-warning">Guardar cambios</button>
			</form>
		  </div>
		</div>

		<br>

		<div class="card">
		  <div class="card-header">
		    Blanquear contraseña
		  </div>
		  <div class="card-body">
			<form action="<?php echo e(route('blanquear.password', $usuario->id)); ?>"  method="post">
			  <?php echo csrf_field(); ?>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Contraseña nueva</label>
			    <input type="password"  name="password" class="form-control">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlInput1">Reingrese la contraseña</label>
			    <input type="password"  name="password_confirmation" class="form-control">
			  </div>
			  <button type="submit" class="btn btn-warning">Blanquear</button>
			</form>
		  </div>
		</div>

		<br>

		<a href="<?php echo e(route('admin.home')); ?>"><button type="button" class="btn btn-secondary btn-sm">Volver</button></a>

	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/admin/editarUsuario.blade.php ENDPATH**/ ?>