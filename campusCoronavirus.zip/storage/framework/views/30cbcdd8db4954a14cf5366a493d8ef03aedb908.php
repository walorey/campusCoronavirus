<?php $__env->startSection('content'); ?>
	<div class="container">
		
		<?php if(session('mensaje')): ?>
	    <div class="alert alert-success fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('mensaje')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<?php if(session('error')): ?>
	    <div class="alert alert-danger fade show">
	    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			</button>
	        <ul>
				<?php echo e(session('error')); ?>

	        </ul>
	    </div>
		<?php endif; ?>
		<div class="row justify-content-center">
        	<div class="col-md-8">
				<div class="card">
		            <div class="card-header">Configuración</div>
					<div class="card-body">
						<h4>Cambiar email</h4>
						<form action="<?php echo e(route('cambiar.email.config')); ?>" method="post">
							<?php echo csrf_field(); ?>
							<div class="form-group">
							    <label for="exampleFormControlInput1">Email</label>
							    <input type="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" name="email" placeholder="name@example.com">
							</div>
							<button type="submit" class="btn btn-primary">Guardar</button>
						</form>
						<br>
						<h4>Cambiar contraseña</h4>
						<form action="<?php echo e(route('modificar.password.config')); ?>" method="post">
							<?php echo csrf_field(); ?>
							<div class="form-group">
							    <label for="exampleInputPassword1">Contraseña actual</label>
							    <input type="password" name="password_actual" class="form-control" required>
							</div>
							<div class="form-group">
							    <label for="exampleInputPassword1">Contraseña nueva</label>
							    <input type="password" class="form-control" name="password" required>
							</div>
							<div class="form-group">
						    	<label for="exampleInputPassword1">Reingrese contraseña</label>
						    	<input type="password" class="form-control" name="password_confirmation" required>
						  	</div>
							<button type="submit" class="btn btn-primary">Guardar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\campusCoronavirus\resources\views/configuracion.blade.php ENDPATH**/ ?>